<div>
  <img src="{{url('uploadedimages/1642858504.png')}}" alt="Not yet ready" width='200' height='200'>
</div>