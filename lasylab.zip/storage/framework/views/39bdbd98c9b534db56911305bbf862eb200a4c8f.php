<?php $__env->startComponent('scribe::components.badges.base', [
    'colour' => \Knuckles\Scribe\Tools\WritingUtils::$httpMethodToCssColour[$method],
    'text' => $method,
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\laragon\www\lasylab\vendor\knuckleswtf\scribe\src/../resources/views//components/badges/http-method.blade.php ENDPATH**/ ?>