<div>
  <img src="<?php echo e(url('uploadedimages/1642858504.png')); ?>" alt="Not yet ready" width='200' height='200'>
</div><?php /**PATH C:\laragon\www\lasylab\resources\views/test.blade.php ENDPATH**/ ?>